export const renderUserProfile = (req, res, next) => {
  res.render("profile");
};
