export const renderIndex = (req, res) => {
  res.render("index");
};
